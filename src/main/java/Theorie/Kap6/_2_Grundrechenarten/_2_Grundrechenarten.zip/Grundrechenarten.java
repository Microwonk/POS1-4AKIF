package Theorie.Kap6._2_Grundrechenarten;

public interface Grundrechenarten {

    Bruch add(Bruch b);
    Bruch multiply (Bruch b);
    Bruch subtract (Bruch b);
    Bruch divide (Bruch b);

}
