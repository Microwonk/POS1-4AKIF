package Theorie.Kap6._2_Grundrechenarten;

public class Main {
    public static void main (String[] args) {
        Bruch b = new Bruch(120301203, 1239120192);
        System.out.println(b);
    }
}
