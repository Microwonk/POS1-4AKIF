package Theorie.Kap6._3_Geometrie;

public interface FigurHelper {

    double getUmfang ();
    double getArea ();

}
