package Theorie.Kap6._5_Laptop;

public class RAM {}
