package Theorie.Kap6._5_Laptop;

public class Schreibkopf
{
    public Schreibkopf()
    {

    }
}
